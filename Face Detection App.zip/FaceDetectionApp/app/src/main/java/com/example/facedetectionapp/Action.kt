package com.example.facedetectionapp


enum class Action {
    QR_SCANNER, FACE_DETECTION
}
